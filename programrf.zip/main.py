from ultralytics import YOLO
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture

def get_gmm_thresholds(pixel_values, n_components=3):
    pixel_values = pixel_values.reshape(-1, 1).astype(np.float32)
    gmm = GaussianMixture(n_components=n_components, random_state=0)
    gmm.fit(pixel_values)

    # Get the means and sort them to assign to tissue classes
    means = gmm.means_.flatten()
    sorted_idx = np.argsort(means)
    sorted_means = means[sorted_idx]

    # Midpoints between means = thresholds
    T1 = int((sorted_means[0] + sorted_means[1]) / 2)  # muscle–fat boundary
    T2 = int((sorted_means[1] + sorted_means[2]) / 2)  # fat–fibrous boundary

    return T1, T2

def main():
    # Loadings
    name='A2.png'
    model = YOLO('best.pt')
    img = cv2.imread(name)
    results = model(img, verbose=False)[0]

    mask_total = np.zeros(img.shape[:2], dtype=np.uint8)

    # combine mask
    for seg in results.masks.data:
        mask = seg.cpu().numpy().astype(np.uint8) * 255
        mask = cv2.resize(mask, (mask_total.shape[1], mask_total.shape[0]))
        mask_total = cv2.bitwise_or(mask_total, mask)

    rgba = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
    rgba[:, :, 3] = mask_total  # masking

    cv2.imwrite(f'{name}_segmentation_mask.png', rgba)

    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    masked_gray = cv2.bitwise_and(gray_img, gray_img, mask=mask_total)

    # --- Triple-Threshold Segmentation ---
    # Compute T1, T2 using GMM
    rf_pixels = masked_gray[mask_total > 0].flatten()
    T1, T2 = get_gmm_thresholds(rf_pixels)
    print(f'GMM thresholds → T1: {T1}, T2: {T2}')


    # Calculate areas
    muscle_area = np.count_nonzero((masked_gray < T1) & (mask_total > 0))
    fat_area = np.count_nonzero((masked_gray >= T1) & (masked_gray < T2) & (mask_total > 0))
    fibrous_area = np.count_nonzero((masked_gray >= T2) & (mask_total > 0))
    total_area = np.count_nonzero(mask_total)

    # Percentages
    muscle_pct = (muscle_area / total_area) * 100
    fat_pct = (fat_area / total_area) * 100
    fibrous_pct = (fibrous_area / total_area) * 100

    print(f'Total object area: {total_area} pixels')
    print(f'Muscle content (<{T1}): {muscle_pct:.2f}%')
    print(f'Fat content ({T1}–{T2}): {fat_pct:.2f}%')
    print(f'Fibrous content (>{T2}): {fibrous_pct:.2f}%')

    # Highlight masks
    highlight = img.copy()
    muscle_mask = (masked_gray < T1) & (mask_total > 0)
    fat_mask = (masked_gray >= T1) & (masked_gray < T2) & (mask_total > 0)
    fibrous_mask = (masked_gray >= T2) & (mask_total > 0)

    highlight[muscle_mask] = [0, 0, 255]     # Blue for muscle
    highlight[fat_mask] = [0, 255, 255]        # Green for fat
    highlight[fibrous_mask] = [0, 255, 0]    # Red for fibrous

    cv2.imwrite(f'{name}_highlighted_output.png', highlight)
    highlight_rgba = cv2.cvtColor(highlight, cv2.COLOR_BGR2BGRA)
    highlight_rgba[:, :, 3] = mask_total
    
    cv2.imwrite(f'{name}_highlighted_transparent.png', highlight_rgba)
    # Flatten grayscale values inside the mask
    rf_pixels = masked_gray[mask_total > 0].flatten()

    # --- Save individual component highlights ---
    # Start from the original image
    muscle_only = img.copy()
    fat_only = img.copy()
    fibrous_only = img.copy()

    # Zero out pixels that are not part of the target tissue
    muscle_only[~muscle_mask] = img[~muscle_mask]
    fat_only[~fat_mask] = img[~fat_mask]
    fibrous_only[~fibrous_mask] = img[~fibrous_mask]

    # Color only the target tissue in place
    muscle_only[muscle_mask] = [0, 0, 255]     # Blue
    fat_only[fat_mask] = [0, 255, 255]         # Yellow-green
    fibrous_only[fibrous_mask] = [0, 255, 0]   # Green

    # Save the images
    cv2.imwrite(f'{name}_highlighted_muscle_only.png', muscle_only)
    cv2.imwrite(f'{name}_highlighted_fat_only.png', fat_only)
    cv2.imwrite(f'{name}_highlighted_fibrous_only.png', fibrous_only)



    # Plot histogram
    plt.figure(figsize=(10, 4))
    plt.hist(rf_pixels, bins=100, color='gray', edgecolor='black')
    plt.axvline(T1, color='blue', linestyle='--', label=f'T1 = {T1} (muscle↔fat)')
    plt.axvline(T2, color='red', linestyle='--', label=f'T2 = {T2} (fat↔fibrous)')
    plt.title(f'{name}: Pixel Intensity Histogram within Rectus Femoris (W/GMM)')
    plt.xlabel('Grayscale Intensity (0-255)')
    plt.ylabel('Pixel Count')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f'{name}_grayscale_histogram.png')
    plt.close()


if __name__ == '__main__':
    main()