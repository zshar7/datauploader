from ultralytics import YOLO
import cv2
import numpy as np

def main():
    # Loadings
    model = YOLO('best.pt')
    img = cv2.imread('images.jpeg')
    results = model(img, verbose=False)[0]

    mask_total = np.zeros(img.shape[:2], dtype=np.uint8)

    # combine mask
    for seg in results.masks.data:
        mask = seg.cpu().numpy().astype(np.uint8) * 255
        mask = cv2.resize(mask, (mask_total.shape[1], mask_total.shape[0]))
        mask_total = cv2.bitwise_or(mask_total, mask)

    rgba = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
    rgba[:, :, 3] = mask_total  # masking

    cv2.imwrite("segmentation_mask.png", rgba)

    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    masked_gray = cv2.bitwise_and(gray_img, gray_img, mask=mask_total)

    # Thresholding
    threshold = 42
    total_area = np.count_nonzero(mask_total)
    below_area = np.count_nonzero((masked_gray < threshold) & (mask_total > 0))
    above_area = np.count_nonzero((masked_gray > threshold) & (mask_total > 0))

    below_pct = (below_area / total_area) * 100
    above_pct = (above_area / total_area) * 100

    print(f'Total object area: {total_area} pixels')
    print(f'Possible lipid content ({threshold}): {below_pct:.2f}%')
    print(f'Possible lean muscle content ({threshold}): {above_pct:.2f}%')

    highlight = img.copy()

    # masks
    above_mask = (masked_gray > threshold) & (mask_total > 0)
    below_mask = (masked_gray < threshold) & (mask_total > 0)

    # Apply red for muscle, yellow for lipid
    highlight[above_mask] = [0, 0, 255]
    highlight[below_mask] = [0, 255, 255]

    cv2.imwrite("highlighted_output.png", highlight)
    highlight_rgba = cv2.cvtColor(highlight, cv2.COLOR_BGR2BGRA)
    highlight_rgba[:, :, 3] = mask_total
    
    cv2.imwrite("highlighted_transparent.png", highlight_rgba)


if __name__ == '__main__':
    main()